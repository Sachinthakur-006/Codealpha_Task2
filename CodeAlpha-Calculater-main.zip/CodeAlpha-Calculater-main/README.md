# CodeAlpha-Calculater
linkedin profile link https://www.linkedin.com/in/sachin-kumar-70349a255/
"Just wrapped up Task 2 for my CodeAlpha internship! 💻 Each challenge is a stepping stone towards mastering my skills. Grateful for the opportunity to learn and innovate! #CodeAlpha #InternshipJourney #TechGrowth"
